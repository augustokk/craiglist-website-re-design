//Augusto Kuusberg Elias
//R00181405
//PROJECT TWO

// make sure the page is ready
$(document).ready(function(){
    // function to allow open collapse bar toggles
    $(".toggle h3").on("click", function(){
        $content  = $(this).attr("id");
        $("."+$content).slideToggle();
    });

    // function to allow change options on faq page for filter
    $(".nav-tabs li").on("click", function(){
        $(".faq").hide();
        $(".nav-tabs li").removeClass("active");
        $(this).addClass("active");
        $tab_active = jQuery(this).attr("id");
        $("."+$tab_active).slideToggle();
    });

});
